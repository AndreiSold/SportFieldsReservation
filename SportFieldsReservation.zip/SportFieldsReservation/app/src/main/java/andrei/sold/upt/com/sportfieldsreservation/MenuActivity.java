package andrei.sold.upt.com.sportfieldsreservation;

import android.support.v7.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {
}
