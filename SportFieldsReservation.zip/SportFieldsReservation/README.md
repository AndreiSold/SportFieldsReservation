# SportFieldsReservation
A mobile app used by sport enthusiasts to see all the available days/hours for football/tennis/... fields in Timisoara or other cities. They also have the option to book one.
